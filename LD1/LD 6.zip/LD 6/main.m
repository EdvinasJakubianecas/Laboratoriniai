%2 Uzd
clc
clear

global x y

x = 2*pi:-0.1:-2*pi;

y = zeros(size(x));

sinusas
vienetas

whos global

plot(x,y,'y--*','LineWidth',1.5)

title('y = sin(x)/x')
xlabel('x')
ylabel('y')

grid on