% Papildoma uzduotis
function varargout = grafsincos(x)

s = sin(x);
c = cos(x);

if nargout == 0

    plot(x,s,'b','LineWidth',1.5)
    hold on
    plot(x,c,'r','LineWidth',1.5)

    legend('sin(x)','cos(x)')
    title('sin(x) ir cos(x)')
    grid on

else

    varargout{1} = s;
    varargout{2} = c;

end

end
%{
 Grazinti reiksmes:
x = 0:0.1:pi;

[s,c] = grafsincos(x)

Brezti grafikus:
x = 0:0.1:pi;

grafsincos(x)
%}